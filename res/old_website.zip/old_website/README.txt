# peterhuangsc.github.io
Personal Website

- Displaying projects, about me, education, courses, and resume
- Includes links to portfolios

Last Modified: April 20 2016